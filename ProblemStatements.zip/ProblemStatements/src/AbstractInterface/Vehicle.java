package AbstractInterface;

public abstract class Vehicle {
    abstract void move();
    abstract void speed();
    abstract void fuel();
}
