package AbstractInterface;

public interface Drivable {
    void drive();
}
