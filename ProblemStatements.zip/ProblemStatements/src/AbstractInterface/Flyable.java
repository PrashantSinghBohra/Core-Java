package AbstractInterface;

public interface Flyable {
    void fly();

}
