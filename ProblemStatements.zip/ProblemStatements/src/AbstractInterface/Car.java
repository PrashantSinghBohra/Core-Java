package AbstractInterface;

/*
 * When to use Abstract Class and Interfaces?

    We use abstract classes when we want to share common code and state among related classes. We use interfaces when we want to define capabilities or contracts that can be applied to any class, regardless of its hierarchy.
 
    Real-world Analogy

    Let’s take a real-world example of a transport system. All vehicles share common properties like speed and fuel, and they all move. But some vehicles can drive, some can fly, and some can float.

    We create an abstract class Vehicle that holds common attributes and behaviors, like speed, fuel, and a method move(). This ensures all vehicles have these properties.

    Then we define interfaces like Drivable and Flyable. These represent capabilities. A car can implement Drivable, and an airplane can implement Flyable. This gives flexibility because a class can implement multiple interfaces.

    So, Car extends Vehicle and implements Drivable. Airplane extends Vehicle and implements Flyable. This way, we combine inheritance for common behavior and interfaces for optional capabilities.

    Note : Abstract class = IS-A relationship; Interface = CAN-DO relationship.
 * 
 * 
 */

public class Car extends Vehicle implements Drivable {
    void move() {
        System.out.println("Car moves on road");
    }

    public void drive() {
        System.out.println("Car is driving");
    }

    @Override
    void speed() {
        System.out.println("My Top Speed is 120 km/hr");

    }

    @Override
    void fuel() {
        System.out.println("Fuel Remaining is 5 literes");

    }
}
