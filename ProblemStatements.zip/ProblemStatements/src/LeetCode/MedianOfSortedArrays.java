package LeetCode;

/*
 *
Example 1 :

Input: nums1 = [1,3], nums2 = [2]
Output: 2.00000
Explanation: merged array = [1,2,3] and median is 2.

Example 2 :

Input: nums1 = [1,2], nums2 = [3,4]
Output: 2.50000
Explanation: merged array = [1,2,3,4] and median is (2 + 3) / 2 = 2.5.

 *
 */
public class MedianOfSortedArrays {

	public static void main(String[] args) {

		int[] arr1 = { 1, 3, 4 };
		int[] arr2 = { 2 };
		findMedianSortedArrays(arr1, arr2);

	}

	public static double findMedianSortedArrays(int[] arr1, int[] arr2) {

		int low = 0;
		int high = arr1.length;
		
		int [] arr3 = new int[arr1.length + arr2.length];
		
		

		while (low < high) {

			int mid = (low + high) / 2;

			if (arr2[low] < arr1[mid]) {
				
				arr3[low + 1] = arr2[low];	
				
			}
			else if (arr2[low] > arr1[mid]) {
				
				
			}

			return 0;

		}
		return high;
	}
}
