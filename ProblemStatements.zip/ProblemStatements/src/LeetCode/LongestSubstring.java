package LeetCode;

import java.util.HashSet;

// abcabcbb

public class LongestSubstring {
	public static int lengthOfLongestSubstring(String string) {
		HashSet<Character> charSet = new HashSet<>();
		int left = 0, maxLength = 0;

		for (int right = 0; right < string.length(); right++) { // right : 2, w
			while (charSet.contains(string.charAt(right))) {
				charSet.remove(string.charAt(left));
				left++;
			}
			charSet.add(string.charAt(right)); // p
			maxLength = Math.max(maxLength, right - left + 1);
		}

		return maxLength;
	}

	public static void main(String[] args) {

		System.out.println(lengthOfLongestSubstring("abcabcbb")); // Output: 3
		System.out.println(lengthOfLongestSubstring("bbbbb")); // Output: 1
		System.out.println(lengthOfLongestSubstring("abcdea")); // Output: 3
	}
}