package LeetCode;

// time complexity : O(2^n)  Exponential Time


public class RecursiveFibonacci {

	public static void main(String[] args) {

		int count = 5256;
		for(int i = 0 ; i < count ; i++) {
			System.out.print(fibonacci(i) + " ");
			
		}
	}

	public static int fibonacci(int n) {
		if (n <= 1)
			return n;
		return fibonacci(n - 1) + fibonacci(n - 2);
	}
}
