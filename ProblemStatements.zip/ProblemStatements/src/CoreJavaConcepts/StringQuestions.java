package CoreJavaConcepts;

public class StringQuestions {

    public static void main(String[] args) {

        // "== checks if two references point to the same object, while .equals() checks if two objects have the same value."
        String a = new String("hello");
        String b = new String("hello");

        System.out.println(a == b); // false (different objects)
        System.out.println(a.equals(b)); // true (same content)

    }
}
