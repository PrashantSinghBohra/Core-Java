package CoreJavaConcepts;

public class StaticNestedClass {

    private String outerClassVariable;

    public String getOuterClassVariable() {
        return outerClassVariable;
    }

    public void setOuterClassVariable(String outerClassVariable) {
        this.outerClassVariable = outerClassVariable;
    }

    public static class InnerClass {

        private String innerClassVariable;

        public String getInnerClassVariable() {
            return innerClassVariable;
        }

        public void setInnerClassVariable(String innerClassVariable) {
            this.innerClassVariable = innerClassVariable;
        }

        void display() {
            System.out.println("Inside Static Inner Class");
        }

    }

    public class NonStaticInnerClas {

        private String nonStaticInnerClassVariable;

        public String getNonStaticInnerClassVariable() {
            return nonStaticInnerClassVariable;
        }

        public void setNonStaticInnerClassVariable(String nonStaticInnerClassVariable) {
            this.nonStaticInnerClassVariable = nonStaticInnerClassVariable;
        }

        void display() {
            System.out.println("Inside Non-Static Inner Class");
        }
    }

    public static void main(String[] args) {

        /*
         * Declared with static keyword inside another class.
         * Belongs to the outer class, not its instance.
         * Cannot access non-static members of the outer class directly.
         * Can access static members of the outer class.
         */

        // Static Nested Class object
        StaticNestedClass.InnerClass obj = new StaticNestedClass.InnerClass();
        obj.display();
        
        /*
         *  non-static inner class is tied to an instance of the outer class.
         *  Can access both static and non-static members of the outer class.
         * 
         */
        
        StaticNestedClass objNonStatic = new StaticNestedClass();
        StaticNestedClass.NonStaticInnerClas objN = objNonStatic.new NonStaticInnerClas();
        objN.display();
    }

}
