package CoreJavaConcepts;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Collections {

    // HashMap vs TreeMap vs LinkedHashMap
    public static void main(String[] args) {

        // Unordered
        // Fastest for insert/search (O(1)) for get/put)
        // Allows one null key and multiple null values
        // Insertion order is not maintained
        // Use Case: When you don’t care about the order of keys.
        Map<String, Integer> hashMap = new HashMap<String, Integer>();

        hashMap.put("Apple", 1);
        hashMap.put("Banana", 2);
        hashMap.put("Carrot", 3);

        System.out.println("HashMap: " + hashMap);

        // Insertion order preserved
        // Allows one null key and multiple null values.
        // Slightly slower than HashMap due to ordering (still O(1))
        // Use Case: When you want predictable iteration order.
        Map<String, Integer> linkedMap = new LinkedHashMap<String, Integer>();
        linkedMap.put("Apple", 1);
        linkedMap.put("Banana", 2);
        linkedMap.put("Carrot", 3);

        System.out.println("linkedMap: " + linkedMap);

        // TreeMap
        // Sorted Order: Keys are automatically sorted in natural order (e.g., alphabetical for strings, ascending for numbers).
        // Custom Sorting: You can provide a custom comparator to define your own sorting logic.
        // No Null Keys: TreeMap does not allow null keys, but allows null values.
        Map<String, Integer> treeMap = new TreeMap<String, Integer>();

        treeMap.put("Banana", 2);
        treeMap.put("Carrot", 3);
        treeMap.put("Apple", 1);

        // Natural Sorting Example
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.print(entry.getKey() + " => " + entry.getValue() + " ");
        }

        //Custom Order (Descending):
        TreeMap<String, Integer> map = new TreeMap<>(Comparator.reverseOrder());
        map.put("Banana", 2);
        map.put("Apple", 1);
        map.put("Cherry", 3);

        System.out.println("Custom Order (Descending):");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.print(entry.getKey() + " => " + entry.getValue() + " ");
        }
        System.out.println("Difference Between List and Set Interface");
        List<String> list = new ArrayList<>();
        Set<String> set = new HashSet<>();

        list.add("Apple");
        list.add("Banana");
        list.add("Apple"); // Duplicate allowed

        set.add("Apple");
        set.add("Banana");
        set.add("Apple"); // Duplicate ignored and it is not allowed

        System.out.println("List: " + list); // [Apple, Banana, Apple]
        System.out.println("Set: " + set); // [Apple, Banana] (order not guaranteed)

    }

}
