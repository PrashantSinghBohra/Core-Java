package CoreJavaConcepts;

public class CallByValueAndReference {

    static class Person {
        String name;
    }

    public static void main(String[] args) {
        
        /*
        * Java passes a copy of the reference to the object.
        So, both the original and the method parameter point to the same object.
        If you change the object’s internal state, it will reflect outside.
        But if you reassign the reference, it won’t affect the original.
        
        
         * 🔍 What’s Happening?
            p holds a reference to a Person object.
            modify(p) passes a copy of that reference.
            Inside modify(), person.name = "Rahul" changes the object that both p and person point to.
            But person = new Person() only changes the local copy of the reference — p in main() is unaffected.
         */
        Person p = new Person();
        p.name = "Prashant";

        modify(p);
        System.out.println(p.name); // Output: "Rahul"
        
        /*
         * 🔹 1. For Primitives (like int, float, boolean)
                Java passes a copy of the actual value.
                So, changes inside the method do not affect the original variable.
         */

        int x = 10;
        modifyPrimitiveValue(x);  
        System.out.println(x);// Output: 10

    }
    

    public static void modifyPrimitiveValue(int num) {
          num = 20;
      }


    public static void modify(Person person) {
        person.name = "Rahul"; // ✅ This changes the original object's field
        person = new Person(); // ❌ This does NOT change the original reference
        person.name = "Amit"; // This affects only the new object, not the original
    }

}
