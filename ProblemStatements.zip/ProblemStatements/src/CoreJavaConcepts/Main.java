package CoreJavaConcepts;

public class Main {
    public static void main(String[] args) {
        Animal myDog = new Dog("Buddy", "Omnivorous"); // Polymorphism: Upcasting
        myDog.makeSound(); // Output: Buddy says: Woof!

        //static method 
        //This is method hiding, not overriding.
        //Static methods are resolved at compile time using the reference type.
        //Static methods are class-level, not object-level.
        // When you do Animal d = new Dog();, the reference type is Animal.
        // Static methods are resolved at compile time, based on the reference type, not the actual object.

        Animal a = new Dog();
        a.info(); 
        Animal.info();

    }
}