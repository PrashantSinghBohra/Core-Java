package CoreJavaConcepts;

//Inheritance
public class Dog extends Animal {

    public Dog() {
        super();
    }

    public Dog(String name, String category) {
        super(name, category);
    }
    
    //static method
    public static void info() {
        System.out.println("This is a Dog (static method)");
    }


    // Polymorphism: Method Overriding or Run Time Polymorphism
    @Override
    public void makeSound() {
        System.out.println(getName() + " says: Woof!");
    }

}