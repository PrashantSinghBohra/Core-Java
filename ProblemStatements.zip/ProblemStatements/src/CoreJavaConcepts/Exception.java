package CoreJavaConcepts;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Exception {

    public static void main(String[] args) {

        // Exceptions checked at compile-time
        // Checked exceptions must be declared with throws or handled with try-catch.

        checkedExceptionExamples();

        // Unchecked exceptions don’t require declaration.
        unCheckedExceptionExamples();

    }

    private static void unCheckedExceptionExamples() {
        // ArithmeticException is unchecked, so no compile-time error, but runtime failure.
        int num = 10 / 0; // ArithmeticException (unchecked)
        System.out.println(num);

    }

    static void checkedExceptionExamples() {
        // FileNotFoundException is checked, so the compiler forces you to handle it.
        try {
            FileReader fr = new FileReader("file.txt"); // Checked exception
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

    }

    // Declares the exceptions a method can throw
    void checkAge(int age) throws IllegalArgumentException {
        if (age < 18) {
            throw new IllegalArgumentException("Age must be 18 or above");
        }
    }

}
