package CoreJavaConcepts;

//Abstraction & Encapsulation
public class Animal {

    private String name; // Encapsulation
    private String dietCategory;

    // default constructor
    public Animal() {

    }

    // parameterized Constructor
    public Animal(String name, String category) {
        this.name = name;
        this.dietCategory = category;
    }

    // Overloaded method with Single parameters
    public void makeSound() { // Abstraction
        System.out.println("Some generic animal sound");
    }

    // Overloaded method with two parameters
    public void makeSound(String soundType, int times) {
        for (int i = 0; i < times; i++) {
            System.out.println("Animal makes a " + soundType + " sound");
        }
    }

    // static method
    public static void info() {
        System.out.println("This is an Animal (static method)");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getDietCategory() {

        return dietCategory;

    }

    public void setDietCaString(String dietCategory) {
        this.dietCategory = dietCategory;
    }

}
