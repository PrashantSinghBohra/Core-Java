package Java8Features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Stream {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);

        // filter method uses parameter Predicate Interface (Functional Interface)
        // Returns a stream consisting of the elements of this stream that match the given predicate.

        // forEach method uses parameter Consumer Interface (Functional Interface)
        // Performs an action for each element of this stream. 
        numbers.stream()
                .filter(n -> n % 2 == 0)
                .forEach(System.out::println);

        // Double each number using map
        // Returns a stream consisting of the results of applying the givenfunction to the elements of this stream. 
        List<Integer> doubles = numbers.stream()
                .map(n -> n * 2)
                .collect(Collectors.toList());
        
        
        /*
         * Q: What is the difference between map() and forEach()?
              map() transforms data and returns a new stream.
              forEach() is used to perform an action (like printing) but does not return a new stream.
         */


        System.out.println(doubles);

    }

}
