package Java8Features;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MapVsFlatMap {

    public static void main(String [] args) {

        /*
         * 🔍 Simple Analogy
         * Imagine you have a list of boxes, and each box contains some items.
         * map(): You open each box and get a list of items. You now have a list of lists.
         *               Transforms each element individually and returns a Stream of Streams if the transformation itself returns a stream.
         * flatMap(): You open each box and pour all items into one big box — a single list of all items.
         *               Flattens the nested structure into a single stream. Useful when each element is a collection or stream.
         */

        Box box1 = new Box(Arrays.asList(new Item("Pencil"), new Item("Rubber")));
        Box box2 = new Box(Arrays.asList(new Item("Sharpener"), new Item("Pen")));
        Box box3 = new Box(Arrays.asList(new Item("Eraser"), new Item("Marker")));

        List<Box> boxes = Arrays.asList(box1, box2, box3);

        // Using map() - returns List<List<Item>>
        List<List<Item>> listOfBoxes = boxes.stream().map(Box::getItems).collect(Collectors.toList());

        System.out.println("Using map():");
        listOfBoxes.forEach(System.out::println);
        
        
        List<Item> flatMappedStreams =  listOfBoxes.stream().flatMap(list -> list.stream()).collect(Collectors.toList());

        System.out.println("\nUsing flatMap() on listOfBoxes:");
        flatMappedStreams.forEach(System.out::println);


    }
}

class Item {
    String name;

    Item(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }

}

class Box {
    List<Item> items;

    Box(List<Item> items) {
        this.items = items;
    }

    public List<Item> getItems() {
        return items;
    }

}
