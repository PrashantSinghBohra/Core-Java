package Java8Features;

import java.util.Optional;

public class OptionalExample {
    public static void main(String[] args) {
        
        /*
         *      Optional is a container object introduced in Java 8 that may or may not contain a non-null value.
                It helps you avoid NullPointerException and write cleaner, safer code when dealing with potentially null values.
         */
        // Creating Optional
        Optional<String> name = Optional.of("Prashant");

        // Check if value is present
        if (name.isPresent()) {
            System.out.println("Name: " + name.get());
        }

        // Using ifPresent
        name.ifPresent(n -> System.out.println("Uppercase: " + n.toUpperCase()));

        // Using orElse
        Optional<String> emptyName = Optional.empty();
        System.out.println("Default Name: " + emptyName.orElse("Default"));

        // Using map
        String greeting = name.map(n -> "Hello, " + n).orElse("Hello, Guest");
        System.out.println(greeting);
    }
}
