package Java8Features;
/*
 *      🔹 Problem with Multiple Inheritance (with classes):
        If Java allowed a class to inherit from multiple classes, it could lead to ambiguity — especially when two parent classes have:
                ○ The same method name
                Or conflicting implementations
       This is called the Diamond Problem, and Java avoids it by not allowing multiple inheritance with classes.
 */

class A {
    void show() {
        System.out.println("A");
    }
}

class B {
    void show() {
        System.out.println("A");
    }
}


//If Java allowed this:

public class AmbiguityDiamondProblem {
    // Which show() should C inherit? A's or B's?
}
