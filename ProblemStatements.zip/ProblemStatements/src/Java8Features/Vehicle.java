package Java8Features;

public interface Vehicle {
    
    
    default void start() {
        System.out.println("Vehicle is starting");
    }

    static void service() {
        System.out.println("Servicing vehicle");
    }

}
