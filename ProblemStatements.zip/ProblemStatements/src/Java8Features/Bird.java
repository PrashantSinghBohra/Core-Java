package Java8Features;

abstract class Animal {
    abstract void makeSound();

    void breathe() {
        System.out.println("Breathing...");
    }
}

interface Flyable {

    /*
     * Before Java 8, interfaces could only have abstract methods. This meant that if you added a new method to an interface,
     * every class implementing that interface had to implement the new method, which could break existing code.
     * To solve this, Java 8 introduced default methods so that:
     * You can add new methods to interfaces without breaking existing implementations.
     * You can provide a default behavior that implementing classes can override if needed.
     */
    default void land() {
        System.out.println("Landing safely");
    }

    void fly();
}

public class Bird extends Animal implements Flyable {
    void makeSound() {
        System.out.println("Chirp");
    }

    public void fly() {
        System.out.println("Flying high");
    }

    public static void main(String[] args) {

        Bird b = new Bird();
        b.fly(); // Bird is flying
        b.land(); // Landing safely (default method)

    }
}
