package Java8Features;

interface As {
    default void show() {
        System.out.println("A's show");
    }
}

interface Bs {
    default void show() {
        System.out.println("B's show");
    }
}

public class MultipleInheritanceJava implements As, Bs {
    // Must override to resolve conflict
    // Java will not compile unless you override show() in class C.
    public void show() {
        System.out.println("C's own show");
    }
}
