package Java8Features;

@FunctionalInterface
interface Greeting {
    abstract void sayHello(String name);
    // abstract void sayHelloAgain(String name); --> It can have only one abstract method

}

public class PrashantGreeting implements Greeting {

    @Override
    public void sayHello(String name) {
        System.out.println("Hi " + name);

    }

    public static void main(String[] args) {

        Greeting prashant = new PrashantGreeting();
        prashant.sayHello("Prashant");
        
        Greeting lambdaExpression  = (name) -> System.out.println("Hi " + name);
        lambdaExpression.sayHello("Prashant");
        
        
    }

}
