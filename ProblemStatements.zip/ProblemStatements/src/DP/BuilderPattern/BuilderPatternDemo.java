package DP.BuilderPattern;


public class BuilderPatternDemo {
    public static void main(String[] args) {
        Computer gamingPC = new Computer.Builder("Intel i9", 32)
                                .setStorage(1000)
                                .setGraphicsCard(true)
                                .build();

        gamingPC.showSpecs();

        Computer officePC = new Computer.Builder("Intel i5", 8)
                                .setStorage(512)
                                .build();

        officePC.showSpecs();
    }
}
