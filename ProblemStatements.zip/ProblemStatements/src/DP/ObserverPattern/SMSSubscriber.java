package DP.ObserverPattern;


public class SMSSubscriber implements Observer {
    public void update(String message) {
        System.out.println("SMS received: " + message);
    }
}
