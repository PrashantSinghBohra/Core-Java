package DP.ObserverPattern;


public interface Observer {
    void update(String message);
}

