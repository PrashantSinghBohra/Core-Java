package DP.ObserverPattern;


public class ObserverPatternDemo {
    public static void main(String[] args) {
        NotificationService service = new NotificationService();

        Observer email = new EmailSubscriber();
        Observer sms = new SMSSubscriber();

        service.attach(email);
        service.attach(sms);

        service.notifyObservers("New video uploaded!");
    }
}
