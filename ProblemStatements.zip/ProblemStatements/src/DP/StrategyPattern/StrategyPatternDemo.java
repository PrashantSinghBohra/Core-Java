package DP.StrategyPattern;

public class StrategyPatternDemo {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        // Pay using Credit Card
        cart.setPaymentStrategy(new CreditCardPayment());
        cart.checkout(1000);

        // Pay using PayPal
        cart.setPaymentStrategy(new PayPalPayment());
        cart.checkout(500);

        // Pay using UPI
        cart.setPaymentStrategy(new UpiPayment());
        cart.checkout(750);
    }
}
