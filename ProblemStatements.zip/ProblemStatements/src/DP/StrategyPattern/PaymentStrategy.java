package DP.StrategyPattern;

public interface PaymentStrategy {
    void pay(int amount);

}
