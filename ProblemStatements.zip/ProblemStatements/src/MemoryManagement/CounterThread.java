package MemoryManagement;

public class CounterThread implements Runnable {

    private CounterRaceCondition counter;
    

    CounterThread(CounterRaceCondition counter) {
        this.counter = counter;
    }

    public CounterRaceCondition getCounter() {
        return counter;
    }

    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            counter.counterIncreament();
        }

    }

    public static void main(String[] args) throws InterruptedException {
        CounterRaceCondition crc = new CounterRaceCondition();

        Thread t1 = new Thread(new CounterThread(crc));
        Thread t2 = new Thread(new CounterThread(crc));
        Thread t3 = new Thread(new CounterThread(crc));

        t1.start();
        t2.start();
        t3.start();

        /*
         * In your main() method, you need to wait for all threads to finish before printing the final count.
         * Otherwise, the main thread might print the value before the other threads complete their work.
         * 
         * start() begins the threads.
           join() ensures the main thread waits for each thread to finish.
           Only after all threads complete, the final count is printed — which should now be exactly 3000.
         * 
         * You tell the main() thread:
         * “Wait for t1, t2, and t3 to finish before continuing.”
            This ensures that all increments are completed before printing the final count.
         * 
         */
        t1.join();
        t2.join();
        t3.join();

        /*
         * You expect the final count to be 3000 (3 threads × 1000 increments).
         * But due to race conditions, the actual output will likely be less than 3000.
         * Each run may give a different result, depending on thread scheduling.
         */
        System.out.println("Final Count " + crc.getCounter());

    }
}
