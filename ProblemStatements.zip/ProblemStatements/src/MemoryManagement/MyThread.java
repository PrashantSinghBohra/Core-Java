package MemoryManagement;

/*
 * It's a class that also has a run() method.
   You extend it when you want to create a thread directly,  but it limits inheritance (Java allows only single inheritance).
 * Single inheritance limitation: If your class already extends another class, you can't extend Thread.
 */

public class MyThread extends Thread {

    public void run() {
        System.out.println("Thread is Running : " + Thread.currentThread().getName());
    }

}
