package MemoryManagement;

class SharedFlag {
    private boolean running = true; // Not volatile

    public void stop() {
        running = false;
    }

    public void run() {
        System.out.println("Thread started...");
        while (running) {
            // Busy loop
        }
        System.out.println("Thread stopped.");
    }
}
/*
 * Without Volatile
 * t1 might never exit the loop because it keeps reading the cached value of running as true.
   The update in stop() is not visible immediately to t1.
   
   With Volatile
   volatile forces running to be read from main memory every time.
    So when stop() sets running = false, t1 sees the change and exits the loop.
 */

public class VolatileExample {
    public static void main(String[] args) throws InterruptedException {
        SharedFlag flag = new SharedFlag();

        Thread t1 = new Thread(flag::run);
        t1.start();

        Thread.sleep(1000); // Let t1 run for a while
        flag.stop(); // Update running to false

        System.out.println("Stop called.");
    }
}