package MemoryManagement;

public class RunnableThreadDemo {

    public static void main(String[] args) {
       Thread t1 = new Thread(new MyRunnableThread());
       Thread t2 = new Thread(new MyRunnableThread());
       Thread t3 = new Thread(new MyRunnableThread());
       
       t1.start();
       t2.start();
       t3.start();
       
       

       /*
        * This creates an anonymous inner class that implements Runnable.
          It is not a lambda because it explicitly defines a class body.
          Boilerplate code: new Runnable() { ... }.
        */
       
       Runnable r1 = new Runnable() {
           public void run() {
               System.out.println("Hello from Runnable");
           }
       };

       

       /*
        * Lambda expressions in Java 8 are primarily used to implement functional interfaces like Runnable, Comparator, etc.
        * They provide a clear and concise syntax for implementing functional interfaces (interfaces with a single abstract method). 
        * They help reduce boilerplate code, especially in collections and functional programming.
        * 
        * 
        * This is a lambda expression.
          It is a shorthand for implementing a functional interface (an interface with one abstract method).
          No class body, no new Runnable() syntax.
          More concise and readable.
        */
        // With Lambda Expression
        Runnable r2 = () -> System.out.println("Hello from Lambda");
        Thread lambda = new Thread(r2);
        lambda.start();

    }

}
