package MemoryManagement;

public class CounterRaceCondition {

    private int counter;

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    /*
     * Both threads access and modify count simultaneously.
     * If both threads do this at the same time, some increments are lost.
     */

    public synchronized void counterIncreament() {
        counter++;

    }

}
