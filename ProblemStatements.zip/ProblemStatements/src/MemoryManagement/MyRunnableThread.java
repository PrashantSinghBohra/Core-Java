package MemoryManagement;


/*
 *  It's an interface with a single method run().
    You implement it when you want to share the same object across multiple threads.
    Preferred in real-world applications (more flexible).
 * 
 * 
 * Q: Why is implementing Runnable preferred over extending Thread?
   A: Because it promotes better object-oriented design, avoids inheritance limitations, and allows the same Runnable instance to be shared across multiple threads.
 */
public class MyRunnableThread implements Runnable {

    @Override
    public void run() {
        System.out.println("Runnable Thread running: " + Thread.currentThread().getName());
    }

}
