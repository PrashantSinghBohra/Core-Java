package SolidPrinciple;


//  Open/Closed Principle (OCP)

abstract class Shape {
    abstract double area();
}

class Circle extends Shape {
    double radius = 5;

    public double area() {
        return Math.PI * radius * radius;
    }
}

class Rectangle extends Shape {
    double length = 4, breadth = 6;

    public double area() {
        return length * breadth;
    }
}
