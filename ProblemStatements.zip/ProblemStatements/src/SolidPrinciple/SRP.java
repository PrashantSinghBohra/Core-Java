package SolidPrinciple;

//Single Responsibility Principle
public class SRP {

}

class Invoice {
    public double calculateTotal() {
        // logic to calculate total
        return 1000.0;
    }
}

class InvoicePrinter {
    public void print(Invoice invoice) {
        System.out.println("Invoice Total: " + invoice.calculateTotal());
    }

}