package SolidPrinciple;

public class LiskovBadExample {

}


class Bird {
    void fly() {
        System.out.println("Flying");
    }
}

class Ostrich extends Bird {
    @Override
    void fly() {
        throw new UnsupportedOperationException("Ostrich can't fly");
    }
}


//Better Design


interface Flyable {
    void fly();
}

class Sparrow implements Flyable {
    public void fly() {
        System.out.println("Sparrow flying");
    }
}

