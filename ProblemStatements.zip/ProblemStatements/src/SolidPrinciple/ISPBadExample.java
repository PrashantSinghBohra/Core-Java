package SolidPrinciple;

//Interface Segregation Principle (ISP)

public class ISPBadExample {

}

interface Worker {
    void work();

    void eat();
}

class Robot implements Worker {
    public void work() {
    }

    public void eat() {
    } // Not applicable
}

// Better Design
/*

interface Workable {
    void work();
}

interface Eatable {
    void eat();
}

class Robot implements Workable {

    public void work() {
    }
}

*/
