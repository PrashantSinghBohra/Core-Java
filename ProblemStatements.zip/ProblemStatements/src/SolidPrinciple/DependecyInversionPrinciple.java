package SolidPrinciple;

//Abstraction
interface TV {
    void turnOn();

    void turnOff();
}

//Low-level modules
class SonyTV implements TV {
    public void turnOn() {
        System.out.println("Sony TV is ON");
    }

    public void turnOff() {
        System.out.println("Sony TV is OFF");
    }
}

class SamsungTV implements TV {
    public void turnOn() {
        System.out.println("Samsung TV is ON");
    }

    public void turnOff() {
        System.out.println("Samsung TV is OFF");
    }
}

//High-level module
class RemoteControl {
    private TV tv;

    // Inject abstraction
    public RemoteControl(TV tv) {
        this.tv = tv;
    }

    public void pressPowerButton() {
        tv.turnOn();
    }

    public void pressOffButton() {
        tv.turnOff();
    }
}

//Main
public class DependecyInversionPrinciple {
    public static void main(String[] args) {
        TV sony = new SonyTV();
        RemoteControl remote = new RemoteControl(sony);
        remote.pressPowerButton();
        remote.pressOffButton();

        // Switch to SamsungTV without changing RemoteControl
        TV samsung = new SamsungTV();
        RemoteControl anotherRemote = new RemoteControl(samsung);
        anotherRemote.pressPowerButton();
        anotherRemote.pressOffButton();
    }
}
